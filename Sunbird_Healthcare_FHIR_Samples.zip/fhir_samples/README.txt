EMR MODULE — FHIR R4 SAMPLE MESSAGES
=====================================
Solutions Architect: Alaa Himour
For: Development & Integration Testing

FILES (FHIR R4 Transaction Bundles):
  ADT_A01_Admit.json          — Patient + Encounter(IMP) + Condition — maps to HL7 ADT A01
  ADT_A02_Transfer.json       — Encounter location update — maps to HL7 ADT A02
  ADT_A03_Discharge.json      — Encounter status=finished + hospitalization — maps to ADT A03
  ADT_A04_Register_OPD.json   — Patient + Encounter(AMB) — maps to HL7 ADT A04
  ADT_A08_Update.json         — Patient resource update — maps to HL7 ADT A08
  ORM_O01_LabOrder.json       — ServiceRequest x3 (CBC + HbA1c + Lipid) — maps to ORM O01
  ORM_O01_RadOrder.json       — ServiceRequest (Chest X-Ray) — maps to ORM O01
  ORU_R01_LabResult_Normal.json   — DiagnosticReport + 4x Observation — maps to ORU R01
  ORU_R01_LabResult_Critical.json — DiagnosticReport + critical Observations (AA/HH) — maps to ORU R01
  SCH_S12_BookAppointment.json    — Appointment status=booked — maps to SCH S12
  SCH_S14_CancelAppointment.json  — Appointment status=cancelled — maps to SCH S14

HOW TO TEST (Phase 2 FHIR endpoint):
  POST https://api.healthcarecore.sa/api/v1/fhir/Bundle
  Content-Type: application/fhir+json
  Authorization: Bearer <token>
  Body: <paste JSON file content>

FHIR ↔ EMR TABLE MAPPING:
  Patient           → emr_patients + emr_patient_contact + emr_patient_identifier
  Encounter         → emr_encounters
  Encounter(IMP)    → emr_adt_admit (hospitalization sub-element)
  Encounter(AMB)    → emr_adt_register
  Condition         → emr_diagnoses
  ServiceRequest    → emr_orm_order
  DiagnosticReport  → emr_oru_result
  Observation(lab)  → emr_oru_observation
  Observation(vital)→ emr_patient_vitals
  Appointment       → emr_sch_appointment

IDENTIFIERS USED:
  MRN system:         http://rmc.sa/fhir/identifier/mrn
  NID system:         http://nphies.sa/identifier/nid
  Visit number:       http://rmc.sa/fhir/identifier/visit-number
  Placer order:       http://rmc.sa/fhir/identifier/placer-order
  Placer appointment: http://rmc.sa/fhir/identifier/placer-appointment
  LOINC codes:        http://loinc.org
  ICD-10 codes:       http://hl7.org/fhir/sid/icd-10
  SNOMED:             http://snomed.info/sct
