EMR MODULE — HL7 v2.5 SAMPLE MESSAGES
======================================
Solutions Architect: Alaa Himour
For: Development & Integration Testing

FILES:
  ADT_A01_Admit.hl7          — Inpatient admission (Ahmed Al-Rashidi, WARD-MED-A)
  ADT_A02_Transfer.hl7       — Ward transfer (WARD-MED-A → WARD-CCU)
  ADT_A03_Discharge.hl7      — Discharge to home (LOS 6 days)
  ADT_A04_Register_OPD.hl7   — OPD registration (Sara Al-Otaibi, CLINIC-OPD-01)
  ADT_A08_Update.hl7         — Patient demographic update (marital status + phone)
  ORM_O01_LabOrder.hl7       — Lab orders: CBC + HbA1c + Lipid Panel (3 OBR)
  ORM_O01_RadOrder.hl7       — Radiology order: Chest X-Ray PA
  ORU_R01_LabResult_Normal.hl7   — CBC + HbA1c results (normal range)
  ORU_R01_LabResult_Critical.hl7 — Troponin I + CK-MB CRITICAL results (AA/HH flags)
  SCH_S12_BookAppointment.hl7    — Appointment booked (Endocrinology, 15-Feb-2026)
  SCH_S14_CancelAppointment.hl7  — Appointment cancelled (patient request)

HOW TO TEST:
  1. POST raw file content to: POST /emr/integration/inbound
  2. Set Content-Type: text/plain (HL7v2) or application/json (FHIR)
  3. Wrap in the API request body:
     {
       "messageUid": "uuid-test-001",
       "messageControlId": "<MSH-10 value>",
       "messageType": "ADT",
       "eventType": "A01",
       "messageVersion": "2.5",
       "protocol": "HL7V2",
       "sourceSystem": "TEST",
       "sourceFacility": "RMC",
       "rawMessage": "<paste HL7 content here>",
       "tenantRid": 1,
       "branchRid": 1
     }
  4. Check emr_msg_inbound → emr_msg_transaction → target EMR table

SEGMENT REFERENCE:
  MSH — Message header (source, destination, message type)
  EVN — Event type and datetime
  PID — Patient demographics (MRN, name, DOB, gender, address)
  PD1 — Patient additional demographics
  NK1 — Next of kin / emergency contact
  PV1 — Patient visit (class, ward, bed, provider)
  PV2 — Additional visit information
  ORC — Order control
  OBR — Observation request (order/result header)
  OBX — Observation result (individual value)
  NTE — Notes (critical value notification text)
  DG1 — Diagnosis (ICD-10-AM)
  SCH — Schedule (appointment)
  RGS — Resource group
  AIG — Appointment information — general resource
  AIL — Appointment information — location
  AIP — Appointment information — personnel
  ZDS — Custom Z-segment: DICOM Study UID (radiology)
  ZPI — Custom Z-segment: Extended patient info (blood type, nationality)
